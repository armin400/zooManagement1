--INSERT INTO department (departmentName) VALUES ("Account");
INSERT INTO `sda_practical_proj`.`login` (`password`, `userName`) VALUES ('admin', '123');